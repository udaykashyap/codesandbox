import { useContext } from "react";
import Footer from "./Components/Footer";
import Navbar from "./Components/Navbar";
import { ThemeContext } from "./Context/ThemeProvider";
import "./styles.css";

export default function App() {
  const { theme, handleTheme } = useContext(ThemeContext);

  return (
    <div
      style={{
        background: theme == "dark" ? "black" : "white",
        color: theme == "light" ? "black" : "white"
      }}
      className="App"
    >
      <Navbar />
      <div
        style={{
          width: "100%",
          height: "300px",
          // padding: "50px",
          margin: "auto"
        }}
      >
        <h1>Theme:- {theme}</h1>
        <button onClick={handleTheme}>
          {theme == "light" ? "Dark" : "Light"}
        </button>
      </div>
      <Footer />
    </div>
  );
}
