import React from "react";

function Footer() {
  return (
    <div>
      <h3>This is Footer</h3>
      <p style={{ width: "40%", margin: "auto" }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad, unde,
        beatae eum atque a non commodi nostrum ipsam blanditiis distinctio
        molestiae rem! Debitis voluptatum, id consequatur tempore ipsum maiores
        sit vel quasi, veniam quia, saepe expedita quae quis. Dolores explicabo
        veritatis iste animi vero aspernatur possimus hic reprehenderit officiis
        a, rerum sint doloribus error debitis iure sit. Assumenda rem illo
        mollitia quae inventore unde error numquam, eos temporibus vero? Hic,
        doloremque totam rerum cum aliquid, delectus corrupti aliquam veniam
        quam doloribus dolores repudiandae odit, eaque autem iste nemo libero
        quisquam aperiam expedita voluptates commodi voluptate ipsa. Quis
        excepturi eligendi nobis?
      </p>
    </div>
  );
}
export default Footer;
