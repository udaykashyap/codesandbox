import React from "react";

function Navbar() {
  const css = {
    display: "flex",
    justifyContent: "space-around",
    height: "50px",
    borderBottom: "3px solid teal"
  };
  return (
    <div style={css}>
      <h4>Home</h4>
      <h4>Products</h4>
      <h4>Contact Us</h4>
      <h4>About</h4>
      <h4>Login</h4>
    </div>
  );
}

export default Navbar;
